const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

// Conexão com o MongoDB
mongoose.connect('mongodb://localhost:27017/cyyacitydatabase')
  .then(() => {
    console.log('Conectado ao MongoDB');
  })
  .catch(err => {
    console.error('Erro ao conectar ao MongoDB:', err);
  });

// Configurações do servidor
const app = express();
app.use(cors());
app.use(express.json());

// Rotas
const registerRoute = require('./routes/register');
app.use('/api/register', registerRoute);

const loginRoute = require('./routes/login');  // Importa a rota de login
app.use('/api/login', loginRoute);  // Rota de login

const characterRoute = require('./routes/character');  // Importa a rota de personagens
app.use('/api/characters', characterRoute);  // Rota de personagens

const nicknameRoute = require('./routes/nickname');
app.use('/api/nickname', nicknameRoute);

// Inicia o servidor
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
